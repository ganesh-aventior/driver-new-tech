from django.apps import AppConfig


class DriverAdvancedAuthConfig(AppConfig):
    name = 'driver_advanced_auth'
