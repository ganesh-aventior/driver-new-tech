from django.apps import AppConfig


class BlackSpotsConfig(AppConfig):
    name = 'black_spots'
