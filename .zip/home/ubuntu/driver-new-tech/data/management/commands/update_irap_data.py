from django.core.management.base import BaseCommand

from data.tasks.update_irap_data import update_irap_data


class Command(BaseCommand):
    help = 'Incident Bulk Upload'

    def handle(self, *args, **options):
        update_irap_data()
