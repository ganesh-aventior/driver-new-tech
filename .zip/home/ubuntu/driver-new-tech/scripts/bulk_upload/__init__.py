from __future__ import absolute_import

from scripts.bulk_upload.add_incidents_v3_dev import main