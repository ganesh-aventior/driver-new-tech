from django.apps import AppConfig


class UserFiltersConfig(AppConfig):
    name = 'user_filters'
